
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { ArrowRight, Calculator, Info } from 'lucide-react';
import InputField from './InputField';
import ResultCard from './ResultCard';
import { calcularCPA, CPAInputs, CPAResult, formatCurrency, formatPercentage } from '@/utils/cpaCalculator';

const CPACalculator: React.FC = () => {
  const [inputs, setInputs] = useState<CPAInputs>({
    taxaGateway: 3.99,
    taxaPlataforma: 5,
    custoProduto: 50,
    precoVenda: 100,
  });

  const [results, setResults] = useState<CPAResult | null>(null);
  const [isCalculated, setIsCalculated] = useState(false);

  const handleInputChange = (field: keyof CPAInputs, value: string) => {
    const numValue = value === '' ? 0 : parseFloat(value);
    setInputs(prev => ({ ...prev, [field]: numValue }));
  };

  const handleCalculate = () => {
    if (inputs.precoVenda <= 0) {
      toast({
        title: "Erro",
        description: "O preço de venda deve ser maior que zero.",
        variant: "destructive"
      });
      return;
    }

    if (inputs.custoProduto >= inputs.precoVenda) {
      toast({
        title: "Alerta",
        description: "O custo do produto é maior ou igual ao preço de venda. Isso resultará em prejuízo.",
        variant: "destructive"
      });
    }

    const result = calcularCPA(inputs);
    setResults(result);
    setIsCalculated(true);

    toast({
      title: "Cálculo realizado",
      description: `CPA Máximo: ${formatCurrency(result.cpaMaximo)} | CPA Ideal: ${formatCurrency(result.cpaIdeal)}`,
    });
  };

  // Calcular resultados iniciais
  useEffect(() => {
    handleCalculate();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Card className="mb-6 border-blue-100 shadow-sm">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardTitle className="text-2xl flex items-center gap-2">
            <Calculator className="h-6 w-6 text-primary" />
            Calculadora de CPA Otimizado
          </CardTitle>
          <CardDescription>
            Calcule seu CPA máximo e ideal com base nos custos e margens de seu negócio
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <InputField
                id="gateway"
                label="Taxa de Gateway de Pagamento"
                value={inputs.taxaGateway}
                onChange={(value) => handleInputChange('taxaGateway', value)}
                type="number"
                min={0}
                max={100}
                step={0.01}
                suffix="%"
              />
              
              <InputField
                id="plataforma"
                label="Taxa da Plataforma E-commerce"
                value={inputs.taxaPlataforma}
                onChange={(value) => handleInputChange('taxaPlataforma', value)}
                type="number"
                min={0}
                max={100}
                step={0.01}
                suffix="%"
              />
            </div>
            
            <div className="space-y-4">
              <InputField
                id="custo"
                label="Custo do Produto"
                value={inputs.custoProduto}
                onChange={(value) => handleInputChange('custoProduto', value)}
                type="number"
                min={0}
                step={0.01}
                suffix="R$"
              />
              
              <InputField
                id="preco"
                label="Preço de Venda"
                value={inputs.precoVenda}
                onChange={(value) => handleInputChange('precoVenda', value)}
                type="number"
                min={0}
                step={0.01}
                suffix="R$"
              />
            </div>
          </div>
          
          <Button 
            className="mt-6 w-full md:w-auto"
            onClick={handleCalculate}
          >
            Calcular CPA
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
      </Card>

      {results && isCalculated && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ResultCard 
              title="CPA Máximo" 
              value={results.cpaMaximo}
              description="Valor máximo para aquisição de cliente com lucro zero"
              isHighlight={true}
            />
            <ResultCard 
              title="CPA Ideal" 
              value={results.cpaIdeal}
              description="Valor ideal para aquisição de cliente com 30% de lucro"
              isHighlight={true}
            />
          </div>
          
          <Card className="bg-white shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Info className="h-5 w-5 text-primary" />
                Detalhes Financeiros
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Faturamento Bruto</p>
                  <p className="text-lg font-semibold">{formatCurrency(results.faturamentoBruto)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Faturamento Líquido</p>
                  <p className="text-lg font-semibold">{formatCurrency(results.faturamentoLiquido)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Margem Bruta</p>
                  <p className="text-lg font-semibold">{formatCurrency(results.margemBruta)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Lucro Operacional (30%)</p>
                  <p className="text-lg font-semibold">{formatCurrency(results.lucroOperacional)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Percentual de Lucro</p>
                  <p className="text-lg font-semibold">{formatPercentage(results.percentualLucro)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Custo do Produto</p>
                  <p className="text-lg font-semibold">{formatCurrency(inputs.custoProduto)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default CPACalculator;
