
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatCurrency } from '@/utils/cpaCalculator';

interface ResultCardProps {
  title: string;
  value: number;
  description?: string;
  isHighlight?: boolean;
}

const ResultCard: React.FC<ResultCardProps> = ({ 
  title, 
  value, 
  description,
  isHighlight = false
}) => {
  return (
    <Card className={`overflow-hidden ${isHighlight ? 'card-gradient shadow-lg border-blue-200' : 'info-card'}`}>
      <CardHeader className={`pb-2 ${isHighlight ? 'bg-primary/10' : ''}`}>
        <CardTitle className="text-lg font-medium text-gray-700">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-primary mb-1">
          {formatCurrency(value)}
        </div>
        {description && (
          <p className="text-sm text-gray-500">{description}</p>
        )}
      </CardContent>
    </Card>
  );
};

export default ResultCard;
