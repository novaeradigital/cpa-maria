
import React from 'react';
import CPACalculator from '@/components/CPACalculator';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            Calculadora de CPA Otimizado
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Otimize seu orçamento de marketing calculando o valor máximo e ideal
            que você pode pagar por cliente no seu e-commerce.
          </p>
        </header>
        
        <main>
          <CPACalculator />
        </main>
        
        <footer className="mt-16 text-center text-gray-500 text-sm">
          <p>Calculadora de CPA para E-commerce © {new Date().getFullYear()}</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
