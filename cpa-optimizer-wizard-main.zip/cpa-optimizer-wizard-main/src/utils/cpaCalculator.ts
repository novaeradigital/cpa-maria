
/**
 * Calcula o CPA máximo e o CPA ideal com base nas taxas e custos fornecidos
 */
export interface CPAInputs {
  taxaGateway: number; // Porcentagem (0-100)
  taxaPlataforma: number; // Porcentagem (0-100)
  custoProduto: number; // Valor em R$
  precoVenda: number; // Valor em R$
}

export interface CPAResult {
  cpaMaximo: number;
  cpaIdeal: number;
  margemBruta: number;
  faturamentoBruto: number;
  faturamentoLiquido: number;
  lucroOperacional: number;
  percentualLucro: number;
}

export const calcularCPA = (inputs: CPAInputs): CPAResult => {
  const { taxaGateway, taxaPlataforma, custoProduto, precoVenda } = inputs;
  
  // Convertendo as taxas de porcentagem para decimal
  const taxaGatewayDecimal = taxaGateway / 100;
  const taxaPlataformaDecimal = taxaPlataforma / 100;
  
  // Cálculo do faturamento
  const faturamentoBruto = precoVenda;
  
  // Cálculo das taxas
  const valorTaxaGateway = faturamentoBruto * taxaGatewayDecimal;
  const valorTaxaPlataforma = faturamentoBruto * taxaPlataformaDecimal;
  
  // Faturamento líquido (após descontar as taxas)
  const faturamentoLiquido = faturamentoBruto - valorTaxaGateway - valorTaxaPlataforma;
  
  // Margem bruta (faturamento líquido - custo do produto)
  const margemBruta = faturamentoLiquido - custoProduto;
  
  // CPA máximo (considerando lucro zero)
  const cpaMaximo = margemBruta;
  
  // CPA ideal (considerando um lucro de 30% sobre a margem bruta)
  const lucroOperacional = margemBruta * 0.3;
  const cpaIdeal = margemBruta - lucroOperacional;
  
  // Percentual de lucro em relação ao preço de venda
  const percentualLucro = (lucroOperacional / faturamentoBruto) * 100;
  
  return {
    cpaMaximo: Number(cpaMaximo.toFixed(2)),
    cpaIdeal: Number(cpaIdeal.toFixed(2)),
    margemBruta: Number(margemBruta.toFixed(2)),
    faturamentoBruto: Number(faturamentoBruto.toFixed(2)),
    faturamentoLiquido: Number(faturamentoLiquido.toFixed(2)),
    lucroOperacional: Number(lucroOperacional.toFixed(2)),
    percentualLucro: Number(percentualLucro.toFixed(2))
  };
};

export const formatCurrency = (value: number): string => {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
};

export const formatPercentage = (value: number): string => {
  return `${value.toFixed(2)}%`;
};
